package com.mock.dalian.tool.rec.hf.taste.hadoop.item;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableSet;
import java.util.TreeMap;

import com.mock.dalian.tool.rec.hf.hadoop.EntityPrefSourceWritable;
import com.mock.dalian.tool.rec.hf.util.HadoopTools;
import com.mock.dalian.tool.rec.hf.util.HybridConfigurationManager;
import com.mock.dalian.tool.rec.hf.util.PerformanceTuning;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.mahout.cf.taste.hadoop.item.VectorOrPrefWritable;
import org.apache.mahout.common.AbstractJob;
import org.apache.mahout.common.HadoopUtil;
import org.apache.mahout.math.VarIntWritable;
import org.apache.mahout.math.Vector;
import org.apache.mahout.math.Vector.Element;
import org.apache.mahout.math.VectorWritable;
import org.apache.mahout.math.map.OpenIntObjectHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mock.dalian.services.DBService;
import com.mock.dalian.services.data.Employee;
import com.mock.dalian.services.data.Item;
import com.mock.dalian.services.data.Preference;

public class UserRecDataLoaderJob extends AbstractJob {
	private static final Logger LOG = Logger.getLogger(UserRecDataLoaderJob.class.getName());

	public static class RowWrapperMapper extends Mapper<IntWritable, VectorWritable, VarIntWritable, VectorOrPrefWritable> {


		protected void map(IntWritable key, VectorWritable value, Context context) throws IOException, InterruptedException {
			Vector similarityMatrixRow = value.get();

			similarityMatrixRow.set(key.get(), Double.NaN);
			context.write(new VarIntWritable(key.get()), new VectorOrPrefWritable(similarityMatrixRow));
		}
	}

	public static class RecDataLoaderReducer extends Reducer<VarIntWritable, VectorOrPrefWritable, NullWritable, NullWritable> {
		Path capabilityInputPath = new Path(HybridConfigurationManager.getStringProperties("config.path.cf.pref.capability.input", ""));
		private OpenIntObjectHashMap<EntityPrefSourceWritable> idMap;
		private Map<Integer, Employee> userMap = new HashMap<Integer, Employee>();


		protected void setup(Context context) {
			idMap = HadoopTools.readItemIDIndexMap(capabilityInputPath.toString(), context.getConfiguration());
			List<Employee> users = DBService.INSTANCE.getUserStore().selectEmployee();
			for (Employee e : users) {
				userMap.put(e.getId(), e);
			}
		}


		protected void reduce(VarIntWritable lineNumber, Iterable<VectorOrPrefWritable> userRecs, Context ctx) {
			try {
				HashMap<String, TreeMap<String, Map<String, String>>> metoringMap = new HashMap<String, TreeMap<String, Map<String, String>>>();
				JSONObject json = new JSONObject();

				if (userMap.get(lineNumber.get()) == null) {
					return;
				}

				List<Item> orgUserItems = DBService.INSTANCE.getItemStore().selectSkillTitleByUser((int) (lineNumber.get()));
				Iterator<VectorOrPrefWritable> it = userRecs.iterator();
				while (it.hasNext()) {
					VectorOrPrefWritable userRec = it.next();
					Iterator<Element> elements = userRec.getVector().iterateNonZero();
					int count = 0;
					while (elements.hasNext()) {
						Element ele = elements.next();
						int recUserId = Integer.valueOf(ele.index());
						if (recUserId == lineNumber.get()) {
							continue;
						}
						List<Item> recUserItem = DBService.INSTANCE.getItemStore().selectSkillTitleByUser((int) (recUserId));
						Employee recUser = userMap.get(recUserId);
						EntityPrefSourceWritable capibility = idMap.get(recUserId);

						if (capibility == null) {
							continue;
						}
						TreeMap<String, Map<String, String>> person = metoringMap.get(capibility.getCapabilityTitle());
						if (person == null) {
							person = new TreeMap<String, Map<String, String>>();
						}

						Map<String, String> skills = new HashMap<String, String>();
						DecimalFormat formater = new DecimalFormat();
						formater.setMaximumFractionDigits(2);
						formater.setGroupingSize(0);
						formater.setRoundingMode(RoundingMode.FLOOR);

						person.put("(" + formater.format(ele.get())+ ")" + recUser.getEmail(), skills);
						List<ItemValue> compareResult = compareList(orgUserItems, recUserItem);
						for (ItemValue iv : compareResult) {
							skills.put(iv.getTitle() + " (" + iv.isThere + ")", iv.isThere);
						}
						metoringMap.put(capibility.getCapabilityTitle(), person);
					}

					json.put("name", userMap.get(lineNumber.get()).getFirstName());
					json.put("parent", "null");
					JSONArray children = new JSONArray();
					json.put("children", children);

					for (Entry<String, TreeMap<String, Map<String, String>>> categoryEntry : metoringMap.entrySet()) {
						JSONObject jsonJobCat = new JSONObject();
						jsonJobCat.put("name", categoryEntry.getKey() + "[" + categoryEntry.getValue().size() + "]");
						children.put(jsonJobCat);
						JSONArray child = new JSONArray();
						jsonJobCat.put("children", child);
						TreeMap<String, Map<String, String>> personsmap = categoryEntry.getValue();
						NavigableSet<String> personKeySet = personsmap.descendingKeySet();
						int i = 0;
						for (String personKey : personKeySet) {
							Map<String, String> personValue = personsmap.get(personKey);
							if (i >= 5) {
								break;
							}
							i++;
							JSONObject peronJson = new JSONObject();
							peronJson.put("name", personKey + "[" + personValue.size() + "]");
							peronJson.put("parent", categoryEntry.getKey());
							child.put(peronJson);
							JSONArray personChild = new JSONArray();
							peronJson.put("children", personChild);
							int j = 0;
							for (Entry<String, String> skillEntry : personValue.entrySet()) {
								if (j >= 5) {
									break;
								}
								j++;
								count++;
								JSONObject skillJson = new JSONObject();
								skillJson.put("name", skillEntry.getKey());
								skillJson.put("url", skillEntry.getValue());
								personChild.put(skillJson);
							}
						}
						json.put("count", count);
					}

				}
				Preference p = new Preference();
				p.setSource(json.toString());
				p.setUserId(userMap.get(lineNumber.get()).getUid());
				DBService.INSTANCE.getPreferenceStore().insertUserItemRec(p);
			} catch (Exception e) {
				LOG.error(e);
				e.printStackTrace();
			}
		}

	}

	public Job prepareJob(Path path, String outputPath) throws IOException {
		HadoopUtil.delete(this.getConf(), new Path(outputPath));
		Job job = new Job(new Configuration(getConf()));
		Configuration jobConf = job.getConfiguration();
		job.setJobName("Load Recommendation Data");
		job.setJarByClass(UserRecDataLoaderJob.class);
		PerformanceTuning.setIOSort(job);

		job.setMapperClass(RowWrapperMapper.class);
		job.setMapOutputKeyClass(VarIntWritable.class);
		job.setMapOutputValueClass(VectorOrPrefWritable.class);

		job.setReducerClass(RecDataLoaderReducer.class);

		job.setInputFormatClass(SequenceFileInputFormat.class);
		jobConf.set("mapred.input.dir", path.toString());
		jobConf.set("mapred.output.dir", outputPath.toString());
		job.setNumReduceTasks(HybridConfigurationManager.getIntProperties("config.rec.voldemort.reduce.count", 1));

		return job;
	}

	public static List<ItemValue> compareList(List<Item> org, List<Item> rec) {
		List<ItemValue> result = new ArrayList<ItemValue>();
		List<Item> recRemove = new ArrayList<Item>();
		for (Item i : org) {
			ItemValue iv = new ItemValue("-", i.getTitle());
			for (Item j : rec) {
				if (i.getTitle().equals(j.getTitle())) {
					iv.isThere = "=";
					recRemove.add(j);
					break;
				}
			}

		}
		rec.removeAll(recRemove);
		for (Item i : rec) {
			result.add(new ItemValue("+", i.getTitle()));
		}

		return result;
	}

	static class ItemValue extends Item {
		public String isThere = "";

		public ItemValue(String isThere, String title) {
			super("  ", title, "  ");
			this.isThere = isThere;
		}
	}


	public int run(String[] args) throws Exception {
		Path inputPath = new Path("/star/hf/usertmp/similarityMatrix");
		Job loader = prepareJob(inputPath, "/star/hf/usertmp/outp");
		loader.waitForCompletion(true);

		return 0;
	}

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new UserRecDataLoaderJob(), args);
		System.exit(res);
	}

}