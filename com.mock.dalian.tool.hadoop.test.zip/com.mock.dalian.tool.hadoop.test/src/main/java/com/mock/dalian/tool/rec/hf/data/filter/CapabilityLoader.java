package com.mock.dalian.tool.rec.hf.data.filter;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.mock.dalian.tool.rec.hf.hadoop.EntityPrefSourceWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.log4j.Logger;

import com.mock.dalian.services.DBService;
import com.mock.dalian.services.core.CapabilityStore;
import com.mock.dalian.services.data.Capability;


public class CapabilityLoader extends DataLoader {
	private static final Logger LOG = Logger.getLogger(CapabilityLoader.class.getName());
	private SequenceFile.Writer writer = null;
	private FileSystem fs = null;
	private Path inputPath = new Path("/star/hf/capinput/");
	private Configuration conf = null;

	public CapabilityLoader(Configuration conf) throws IOException {
		this.conf = conf;
		this.fs = FileSystem.get(conf);

	}

	public void load() throws IOException {
		try {
			CapabilityStore capabilityStore = DBService.INSTANCE.getCapabilityStore();
			writer = SequenceFile.createWriter(fs, this.conf, new Path(inputPath + File.separator + "part-000000"), LongWritable.class,
					EntityPrefSourceWritable.class);
			LOG.info("NEW FILE CREATED:" + inputPath + File.separator + "prefs-1.dat.");

			
			List<Capability> caps = null;
			LOG.info("Starting loading preferences to HDFS...");
			caps = capabilityStore.selectCapabilities();
			for (Capability capability : caps) {
				writer.append(new LongWritable(Long.parseLong(capability.getUserId())), capabilityToEntityPrefSource(capability));
			}
		} finally {
			IOUtils.closeStream(writer);
		}
		LOG.info("End loading preferences to HDFS...");
	}

	private EntityPrefSourceWritable capabilityToEntityPrefSource(Capability capability) {
		EntityPrefSourceWritable entityPrefSource = new EntityPrefSourceWritable();
		entityPrefSource.set(Long.parseLong(capability.getUserId()), capability.getCapabilityTitle(), capability.getCapNum(),
				capability.getBand());

		return entityPrefSource;
	}
}
