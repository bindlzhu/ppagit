package com.mock.dalian.tool.rec.hf.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.mapreduce.JobContext;

public class PerformanceTuning {

	 public static void setIOSort(JobContext job) {
	      Configuration conf = job.getConfiguration();
	      int assumedHeapSize = 1024;
	      String javaOpts = conf.get("mapred.child.java.opts");
	      if (javaOpts != null) {
	          Matcher m = Pattern.compile("-Xmx([0-9]+)([mMgG])").matcher(javaOpts);
	          if (m.find()) {
	              assumedHeapSize = Integer.parseInt(m.group(1));
	              String megabyteOrGigabyte = m.group(2);
	              if ("g".equalsIgnoreCase(megabyteOrGigabyte)) {
	                  assumedHeapSize *= 1024;
	              }
	          }
	      }

	      conf.setInt("io.sort.mb", assumedHeapSize / 2);
	      conf.setInt("io.sort.factor", 50);
	      conf.setBoolean("mapred.compress.map.output", true);
	      conf.set("mapred.output.compression.type", CompressionType.BLOCK.toString());
	      conf.setInt("mapred.task.timeout", 2 * 60 * 60 * 1000);
	  }
	 
}
