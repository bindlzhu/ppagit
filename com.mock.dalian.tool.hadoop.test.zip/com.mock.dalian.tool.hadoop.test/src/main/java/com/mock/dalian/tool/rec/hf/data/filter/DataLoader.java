package com.mock.dalian.tool.rec.hf.data.filter;

import java.util.HashMap;
import java.util.Map;

import com.mock.dalian.tool.rec.hf.HybridBase;
import com.mock.dalian.tool.rec.hf.util.HybridConfigurationManager;

public abstract class DataLoader implements HybridBase {
    public static char FIELD_SPILITER = ',';
    protected static String LINE_SPILITER = "\n";
    protected static Map<String, Float> sourceKeyMap = new HashMap<String, Float>();
    
    protected static int readConfigAsInt(String key) {
        return Integer.valueOf(HybridConfigurationManager.getStringProperties(key, "0"));
    }
    
    protected static String readConfigAsString(String key) {
        return HybridConfigurationManager.getStringProperties(key, "");
    }
    
    abstract public void load() throws Exception;
}
