package com.mock.dalian.tool.rec.hf.taste.hadoop.item;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.mock.dalian.tool.rec.hf.util.HybridConfigurationManager;
import com.mock.dalian.tool.rec.hf.util.PerformanceTuning;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.mahout.cf.taste.hadoop.RecommendedItemsWritable;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.common.AbstractJob;
import org.apache.mahout.common.HadoopUtil;
import org.apache.mahout.math.VarLongWritable;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mock.dalian.services.DBService;
import com.mock.dalian.services.data.Employee;
import com.mock.dalian.services.data.Item;

public class ItemRecDataLoaderJob extends AbstractJob {


	public static class RecDataLoaderReducer extends Reducer<VarLongWritable, RecommendedItemsWritable, VarLongWritable, VarLongWritable> {
		Path capabilityInputPath = new Path(HybridConfigurationManager.getStringProperties("config.path.cf.pref.capability.input", ""));

		private Map<Integer, Employee> userMap = new HashMap<Integer, Employee>();

		
		protected void setup(Context context) {

			List<Employee> users = DBService.INSTANCE.getUserStore().selectEmployee();
			for (Employee e : users) {
				userMap.put(e.getId(), e);
			}
		}

		
		protected void reduce(VarLongWritable lineNumber, Iterable<RecommendedItemsWritable> userRecs, Context ctx) {

			String uid = userMap.get((int) (lineNumber.get())).getUid();
			if (uid == null) {
				return;
			}
			try {
				Iterator<RecommendedItemsWritable> itemRecit = userRecs.iterator();
				JSONArray records = new JSONArray();
				while (itemRecit.hasNext()) {
					RecommendedItemsWritable riw = itemRecit.next();
					List<RecommendedItem> recList = riw.getRecommendedItems();
					for (RecommendedItem recItem : recList) {
						LinkedHashMap<String, String> jsonOrderedMap = new LinkedHashMap<String, String>();
						JSONObject record = new JSONObject(jsonOrderedMap);
						
						long itemId = recItem.getItemID();
						Item item = DBService.INSTANCE.getItemStore().selectItemById((int) itemId);
						record.put("title", item.getTitle());
						record.put("description", item.getDescription());
						record.put("score", String.valueOf(recItem.getValue()));
						records.put(record);
					}
				}
				
				Item item = new Item();
				item.setTitle(uid);
				item.setDescription(records.toString());
				DBService.INSTANCE.getItemStore().insertItemRec(item);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}

	}

	public Job prepareJob(Path path, String outputPath) throws IOException {
		HadoopUtil.delete(this.getConf(), new Path(outputPath));
		Job job = new Job(new Configuration(getConf()));
		Configuration jobConf = job.getConfiguration();
		job.setJobName("Load Recommendation Data");
		job.setJarByClass(ItemRecDataLoaderJob.class);
		PerformanceTuning.setIOSort(job);

		job.setMapperClass(Mapper.class);
		job.setMapOutputKeyClass(VarLongWritable.class);
		job.setMapOutputValueClass(RecommendedItemsWritable.class);

		job.setReducerClass(RecDataLoaderReducer.class);

		job.setInputFormatClass(SequenceFileInputFormat.class);
		jobConf.set("mapred.input.dir", path.toString());
		jobConf.set("mapred.output.dir", outputPath.toString());
		job.setNumReduceTasks(HybridConfigurationManager.getIntProperties("config.rec.voldemort.reduce.count", 1));

		return job;
	}

	
	public int run(String[] args) throws Exception {
		Path inputPath = new Path("/star/hf/output/");
		Job loader = prepareJob(inputPath, "/star/hf/usertmp/outp");
		loader.waitForCompletion(true);

		return 0;
	}

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new ItemRecDataLoaderJob(), args);
		System.exit(res);
	}

}
