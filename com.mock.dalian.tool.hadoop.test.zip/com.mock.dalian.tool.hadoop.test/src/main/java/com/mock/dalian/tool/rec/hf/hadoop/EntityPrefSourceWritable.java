package com.mock.dalian.tool.rec.hf.hadoop;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.mahout.math.VarLongWritable;

public final class EntityPrefSourceWritable extends VarLongWritable {
	private String capabilityTitle;
	private String capNum;
	private String band;

	public EntityPrefSourceWritable() {
		
	}

	public EntityPrefSourceWritable(long userId, String capabilityTitle, String capNum, String band) {
		super(userId);
		this.capabilityTitle = capabilityTitle;
		this.capNum = capNum;
		this.band = band;
	}

	public EntityPrefSourceWritable(EntityPrefSourceWritable other) {
		this(other.get(), other.getCapabilityTitle(), other.getCapNum(), other.getBand());
	}

	public long getID() {
		return get();
	}

	public void set(long id, String capabilityTitle, String capNum, String band) {
		super.set(id);
		this.capabilityTitle = capabilityTitle;
		this.capNum = capNum;
		this.band = band;
	}

	
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeUTF(capabilityTitle);
		out.writeUTF(capNum);
		out.writeUTF(band);
	}

	
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		capabilityTitle = in.readUTF();
		capNum = in.readUTF();
		band = in.readUTF();
	}

	
	public int hashCode() {
		return super.hashCode() ^ capabilityTitle.hashCode() ^ capNum.hashCode() ^ band.hashCode();
	}

	
	public boolean equals(Object o) {
		if (!(o instanceof EntityPrefSourceWritable)) {
			return false;
		}
		EntityPrefSourceWritable other = (EntityPrefSourceWritable) o;
		return get() == other.get() && capabilityTitle == other.getCapabilityTitle() && capNum == other.getCapNum() && band == other.getBand();
	}

	
	public String toString() {
		return get() + "\t" + capabilityTitle + "\t" + capNum + "\t" + band;
	}

	
	public EntityPrefSourceWritable clone() {
		return new EntityPrefSourceWritable(get(), capabilityTitle, capNum, band);
	}

	
	public String getCapabilityTitle() {
		return capabilityTitle;
	}

	
	public String getCapNum() {
		return capNum;
	}

	
	public String getBand() {
		return band;
	}
}