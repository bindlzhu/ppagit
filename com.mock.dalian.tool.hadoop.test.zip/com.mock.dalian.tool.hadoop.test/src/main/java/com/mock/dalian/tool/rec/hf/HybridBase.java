package com.mock.dalian.tool.rec.hf;

import java.util.Map;
import java.util.TreeMap;


public interface HybridBase {
    Map<String, String> staticsMap = new TreeMap<String, String>();
}
