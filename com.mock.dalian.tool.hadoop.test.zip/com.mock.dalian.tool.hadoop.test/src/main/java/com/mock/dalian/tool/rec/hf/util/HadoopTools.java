package com.mock.dalian.tool.rec.hf.util;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.mahout.common.Pair;
import org.apache.mahout.common.iterator.sequencefile.PathFilters;
import org.apache.mahout.common.iterator.sequencefile.PathType;
import org.apache.mahout.common.iterator.sequencefile.SequenceFileDirIterable;
import org.apache.mahout.math.map.OpenIntObjectHashMap;

import com.mock.dalian.tool.rec.hf.hadoop.EntityPrefSourceWritable;

public class HadoopTools {
    
    public static OpenIntObjectHashMap<EntityPrefSourceWritable> readItemIDIndexMap(String userIDIndexPathStr,
            Configuration conf) {
    	OpenIntObjectHashMap<EntityPrefSourceWritable> indexUserIDMap = new OpenIntObjectHashMap<EntityPrefSourceWritable>();
        Path userIDIndexPath = new Path(userIDIndexPathStr);
        for (Pair<LongWritable, EntityPrefSourceWritable> record : new SequenceFileDirIterable<LongWritable, EntityPrefSourceWritable>(
        		userIDIndexPath, PathType.LIST, PathFilters.partFilter(), null, true, conf)) {
            long indexStatus = record.getFirst().get();
            EntityPrefSourceWritable capability = record.getSecond().clone();
  
			indexUserIDMap.put((int)indexStatus, capability);
        }
        return indexUserIDMap;
    }

}
