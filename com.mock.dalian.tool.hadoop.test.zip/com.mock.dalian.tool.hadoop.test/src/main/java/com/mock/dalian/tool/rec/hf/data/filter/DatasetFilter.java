package com.mock.dalian.tool.rec.hf.data.filter;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.mock.dalian.tool.rec.hf.common.AbstractJob;
import org.apache.hadoop.conf.Configuration;

public class DatasetFilter extends AbstractJob {
	
	public int run(String[] arg0) throws Exception {
		Configuration config = getConf();
		AtomicInteger currentPhase = new AtomicInteger();
		HashMap<String, String> parsedArgs = new HashMap<String, String>();
		 
		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			PreferencesLoader preferencesLoader = new PreferencesLoader(config);
			preferencesLoader.load();
		}

		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			CapabilityLoader capabilityLoader = new CapabilityLoader(config);
			capabilityLoader.load();
		}

		return 0;
	}
}
