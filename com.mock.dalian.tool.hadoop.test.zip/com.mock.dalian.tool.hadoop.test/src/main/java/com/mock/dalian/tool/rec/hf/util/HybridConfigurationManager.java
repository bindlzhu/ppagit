
package com.mock.dalian.tool.rec.hf.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;


public class HybridConfigurationManager {
    
    private static Properties props = new Properties();

    
    private HybridConfigurationManager() {
    }

    
    static {
        try {
            props.load(HybridConfigurationManager.class.getResourceAsStream("/hf-cooccurrence.properties"));
        } catch (IOException e) {
            System.out.println("Failed to load hf-cooccurrence.properties");
        }
    }
    public static int getIntProperties(String name, int def) {
    	return Integer.valueOf(getStringProperties(name, String.valueOf(1)));
    }

    
    public static String getStringProperties(String name, String def) {
        String val = props.getProperty(name, def);
        if (val == null) {
            return def;
        }

        val = val.trim();
        return (val.length() == 0) ? def : val;
    }

    
    public static String[] getStringArrayProperty(String name) {
        String vals = getStringProperties(name, null);
        if (vals == null) {
            return null;
        }

        StringTokenizer strToken = new StringTokenizer(vals, ",");
        ArrayList<String> strs = new ArrayList<String>();

        try {
            while (strToken.hasMoreTokens()) {
                strs.add(strToken.nextToken().trim());
            }

            return (String[]) strs.toArray(new String[strs.size()]);
        } catch (Exception e) {
            return null;
        }
    }

    
    public static Properties getSubProperties(String prefix) {
        Properties properties = new Properties();
        Set<Object> set = props.keySet();

        for (Object key : set) {
            String keyStr = (String) key;
            if (keyStr.startsWith(prefix) && !props.getProperty(keyStr).trim().equals("")) {
                properties.put(keyStr.substring(prefix.length() + 1), props.getProperty(keyStr));
            }
        }

        return properties;
    }
}