package com.mock.dalian.tool.rec.hf.impl.recommender;

import org.apache.mahout.cf.taste.common.Refreshable;
import org.apache.mahout.cf.taste.common.TasteException;


public interface ItemSimStorage extends Refreshable {
  float getSimilarityScore(long itemID1, long itemID2) throws TasteException;
  void addItemSimilarityScore(long userID, long itemID, float similarityScore) throws TasteException;
  void removeItemSimilarity(long userID, long itemID) throws TasteException;
}
