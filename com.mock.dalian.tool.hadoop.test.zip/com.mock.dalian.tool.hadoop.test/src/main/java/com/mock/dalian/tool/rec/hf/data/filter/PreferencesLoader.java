package com.mock.dalian.tool.rec.hf.data.filter;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.mock.dalian.services.core.PreferenceStore;
import com.mock.dalian.services.data.Preference;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;

import com.mock.dalian.services.DBService;

public class PreferencesLoader extends DataLoader {
	private static final Logger LOG = Logger.getLogger(PreferencesLoader.class.getName());
	private FSDataOutputStream outputStreams;
	private FSDataOutputStream userOutputStreams;
	private int fileRecCount = 0;
	private FileSystem fs = null;
	private Path inputPath = new Path("/star/hf/input/");
	private Path userinputPath = new Path("/star/hf/userinput/");
	private static final int PAGESIZE = 5000;
	private static final int STORE_PAGESIZE = 10000;
	
	public PreferencesLoader(Configuration conf) throws IOException {
		this.fs = FileSystem.get(conf);
	}

	public void load() throws IOException {
		
		PreferenceStore preferencesStore = DBService.INSTANCE.getPreferenceStore();
		outputStreams = fs.create(new Path(inputPath + File.separator + "prefs-1.dat"), true);
		userOutputStreams = fs.create(new Path(userinputPath + File.separator + "prefs-1.dat"), true);
		LOG.info("NEW FILE CREATED:" + inputPath + File.separator + "prefs-1.dat.");

		List<Preference> prefs = null;
		LOG.info("Starting loading preferences to HDFS...");
		int index = 0;
		do {
			prefs = preferencesStore.selectHadoopPreferences(index * PAGESIZE, PAGESIZE);
			for (Preference currentPref : prefs) {

				if (fileRecCount > 0 && fileRecCount % STORE_PAGESIZE == 0) {
					IOUtils.closeStream(outputStreams);
					IOUtils.closeStream(userOutputStreams);
					outputStreams = fs.create(new Path(inputPath + "/prefs-" + (fileRecCount / STORE_PAGESIZE + 1) + ".dat"));
					userOutputStreams = fs.create(new Path(userinputPath + "/prefs-" + (fileRecCount / STORE_PAGESIZE + 1) + ".dat"));
					LOG.info("NEW FILE CREATED:" + inputPath + "/prefs-" + (fileRecCount / STORE_PAGESIZE + 1) + ".dat");
				}

				outputStreams.write(preferenceToString(currentPref).getBytes());
				userOutputStreams.write(reversePreferenceToString(currentPref).getBytes());
				fileRecCount++;
			}
			if (prefs.size() < PAGESIZE) {
				break;
			}
			index++;
		} while (true);

		IOUtils.closeStream(outputStreams);
		IOUtils.closeStream(userOutputStreams);
		LOG.info("End loading preferences to HDFS...");
	}

	
	private String preferenceToString(Preference preference) {
		StringBuilder prefencesString = new StringBuilder();
		prefencesString.append(preference.getUserId()).append(FIELD_SPILITER);
		prefencesString.append(preference.getItemId()).append(FIELD_SPILITER);
		float score = preference.getScore();
		prefencesString.append(score);
		prefencesString.append(LINE_SPILITER);
		return prefencesString.toString();
	}
	
	private String reversePreferenceToString(Preference preference) {
		StringBuilder prefencesString = new StringBuilder();
		prefencesString.append(preference.getItemId()).append(FIELD_SPILITER);
		prefencesString.append(preference.getUserId()).append(FIELD_SPILITER);
		float score = preference.getScore();
		prefencesString.append(score);
		prefencesString.append(LINE_SPILITER);
		return prefencesString.toString();
	}
}
