
package com.mock.dalian.tool.rec.hf.taste.hadoop.item;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.mock.dalian.tool.rec.hf.common.AbstractJob;
import com.mock.dalian.tool.rec.hf.data.filter.DatasetFilter;
import com.mock.dalian.tool.rec.hf.similarity.RowSimilarityJob;
import com.mock.dalian.tool.rec.hf.similarity.UserRowSimilarityJob;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.ToolRunner;
import org.apache.mahout.cf.taste.hadoop.EntityPrefWritable;
import org.apache.mahout.cf.taste.hadoop.RecommendedItemsWritable;
import org.apache.mahout.cf.taste.hadoop.ToEntityPrefsMapper;
import org.apache.mahout.cf.taste.hadoop.ToItemPrefsMapper;
import org.apache.mahout.cf.taste.hadoop.item.AggregateAndRecommendReducer;
import org.apache.mahout.cf.taste.hadoop.item.ItemIDIndexMapper;
import org.apache.mahout.cf.taste.hadoop.item.ItemIDIndexReducer;
import org.apache.mahout.cf.taste.hadoop.item.PartialMultiplyMapper;
import org.apache.mahout.cf.taste.hadoop.item.PrefAndSimilarityColumnWritable;
import org.apache.mahout.cf.taste.hadoop.item.RecommenderJob;
import org.apache.mahout.cf.taste.hadoop.item.SimilarityMatrixRowWrapperMapper;
import org.apache.mahout.cf.taste.hadoop.item.ToUserVectorsReducer;
import org.apache.mahout.cf.taste.hadoop.item.ToVectorAndPrefReducer;
import org.apache.mahout.cf.taste.hadoop.item.UserVectorSplitterMapper;
import org.apache.mahout.cf.taste.hadoop.item.VectorAndPrefsWritable;
import org.apache.mahout.cf.taste.hadoop.item.VectorOrPrefWritable;
import org.apache.mahout.cf.taste.hadoop.preparation.ToItemVectorsMapper;
import org.apache.mahout.cf.taste.hadoop.preparation.ToItemVectorsReducer;
import org.apache.mahout.common.HadoopUtil;
import org.apache.mahout.common.iterator.sequencefile.PathType;
import org.apache.mahout.math.VarIntWritable;
import org.apache.mahout.math.VarLongWritable;
import org.apache.mahout.math.VectorWritable;


public final class HybridRecommenderJob extends AbstractJob {
	
	private static final int CF_MAX_SIMILARITIES_PER_ITEM = readConfigAsInt("config.rec.cf.max.similarities.per.item");
	
	private static final int CF_MAX_COOCCURRENCES_PER_ITEM = readConfigAsInt("config.rec.cf.max.cooccurrences.per.item");
	
	private static final int CF_MIN_PREFS_PER_USER = readConfigAsInt("config.rec.cf.min.prefs.per.user");

	
	public int run(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		final String BOOLEAN_DATA = "booleanData";
		boolean booleanData = false;
		int numRecommendations = readConfigAsInt("config.rec.hybrid.num.rec.per.user");
		int maxPrefsPerUser = Integer.parseInt(readConfigAsString("config.rec.max.prefs.per.user.considered"));
		Path inputPath = new Path(readConfigAsString("config.path.cf.pref.input"));
		Path capabilityInputPath = new Path(readConfigAsString("config.path.cf.pref.capability.input"));
		Path userInputPath = new Path(readConfigAsString("config.path.cf.pref.userinput"));
		Path outputPath = new Path(readConfigAsString("config.path.hybrid.rec.output"));
		Path tempDirPath = new Path(readConfigAsString("config.path.cf.temp"));
		Path userTempDirPath = new Path(readConfigAsString("config.path.cf.user.temp"));
		Path uuserVectorPath = new Path(userTempDirPath, readConfigAsString("config.path.cf.user.vector"));
		Path userItemUserMatrixPath = new Path(userTempDirPath, readConfigAsString("config.path.cf.item.user.matrix"));
		Path userSimilarityMatrixPath = new Path(userTempDirPath, readConfigAsString("config.path.cf.similarity.matrix"));
		Path userVectorPath = new Path(tempDirPath, readConfigAsString("config.path.cf.user.vector"));
		Path itemIDIndexPath = new Path(tempDirPath, readConfigAsString("config.path.cf.item.id.index.mapping"));
		Path countUsersPath = new Path(tempDirPath, readConfigAsString("config.path.cf.count.user"));
		Path itemUserMatrixPath = new Path(tempDirPath, readConfigAsString("config.path.cf.item.user.matrix"));
		Path similarityMatrixPath = new Path(tempDirPath, readConfigAsString("config.path.cf.similarity.matrix"));
		Path prePartialMultiplyPath1 = new Path(tempDirPath, readConfigAsString("config.path.hybrid.pre.partial.multiply.1"));
		Path prePartialMultiplyPath2 = new Path(tempDirPath, readConfigAsString("config.path.hybrid.pre.partial.multiply.2"));
		Path partialMultiplyPath = new Path(tempDirPath, readConfigAsString("config.path.hybrid.pre.partial.multiply.8"));
		int minPrefsPerUser = CF_MIN_PREFS_PER_USER;
		int maxSimilaritiesPerItem = CF_MAX_SIMILARITIES_PER_ITEM;
		int maxCooccurrencesPerItem = CF_MAX_COOCCURRENCES_PER_ITEM;
		

		AtomicInteger currentPhase = new AtomicInteger();
		HashMap<String, String> parsedArgs = new HashMap<String, String>();
		if (args.length == 2) {
			parsedArgs.put("startPhase", args[0]);
			parsedArgs.put("endPhase", args[1]);
		}
		
		FileSystem.get(this.getConf()).deleteOnExit(new Path("/star/hf"));
		
		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			try {
				ToolRunner.run(getConf(), new DatasetFilter(), args);
			} catch (Exception e) {
				throw new IllegalStateException("Dataset Filter failed", e);
			}
		}
		
		{
			Job toUserVectors = prepareJob(userInputPath, uuserVectorPath, TextInputFormat.class, ToItemPrefsMapper.class, VarLongWritable.class,
					booleanData ? VarLongWritable.class : EntityPrefWritable.class, ToUserVectorsReducer.class, VarLongWritable.class, VectorWritable.class,
					SequenceFileOutputFormat.class);
			toUserVectors.getConfiguration().setBoolean(RecommenderJob.BOOLEAN_DATA, booleanData);
			toUserVectors.getConfiguration().setInt(ToUserVectorsReducer.MIN_PREFERENCES_PER_USER, minPrefsPerUser);
			toUserVectors.getConfiguration().set(ToEntityPrefsMapper.RATING_SHIFT, String.valueOf(0.0f));
			toUserVectors.waitForCompletion(true);

			
			int numberOfUsers = (int) toUserVectors.getCounters().findCounter(ToUserVectorsReducer.Counters.USERS).getValue();
			HadoopUtil.writeInt(numberOfUsers, countUsersPath, getConf());

			
			Job toItemVectors = prepareJob(uuserVectorPath, userItemUserMatrixPath, SequenceFileInputFormat.class, ToItemVectorsMapper.class, IntWritable.class,
					VectorWritable.class, ToItemVectorsReducer.class, IntWritable.class, VectorWritable.class, SequenceFileOutputFormat.class);
			toItemVectors.setCombinerClass(ToItemVectorsReducer.class);

			

			int samplingSize = maxCooccurrencesPerItem;
			toItemVectors.getConfiguration().setInt(ToItemVectorsMapper.SAMPLE_SIZE, samplingSize);
			toItemVectors.waitForCompletion(true);

			
			if (numberOfUsers == -1) {
				numberOfUsers = (int) HadoopUtil.countRecords(userVectorPath, PathType.LIST, null, getConf());
			}

			
			if (shouldRunNextPhase(parsedArgs, currentPhase)) {
				try {
					ToolRunner.run(getConf(), new UserRowSimilarityJob(), new String[] { "-Dmapred.input.dir=" + userItemUserMatrixPath,
							"-Dmapred.output.dir=" + userSimilarityMatrixPath, "-numberOfColumns", String.valueOf(numberOfUsers), "-similarityClassname", "N/A",
							"-maxSimilaritiesPerRow", String.valueOf(maxSimilaritiesPerItem + 1), 
							"-tempDir", userTempDirPath.toString(), "-thredhold", "0.0", "-capabilityInputPath", capabilityInputPath.toString()});
				} catch (Exception e) {
					throw new IllegalStateException("item-item-similarity computation failed", e);
				}
			}
		}

		Job itemIDIndex = prepareJob(inputPath, itemIDIndexPath, TextInputFormat.class, ItemIDIndexMapper.class, VarIntWritable.class, VarLongWritable.class,
				ItemIDIndexReducer.class, VarIntWritable.class, VarLongWritable.class, SequenceFileOutputFormat.class);
		itemIDIndex.setCombinerClass(ItemIDIndexReducer.class);
		itemIDIndex.waitForCompletion(true);

		Job toUserVectors = prepareJob(inputPath, userVectorPath, TextInputFormat.class, ToItemPrefsMapper.class, VarLongWritable.class,
				booleanData ? VarLongWritable.class : EntityPrefWritable.class, ToUserVectorsReducer.class, VarLongWritable.class, VectorWritable.class,
				SequenceFileOutputFormat.class);
		toUserVectors.getConfiguration().setBoolean(RecommenderJob.BOOLEAN_DATA, booleanData);
		toUserVectors.getConfiguration().setInt(ToUserVectorsReducer.MIN_PREFERENCES_PER_USER, minPrefsPerUser);
		toUserVectors.getConfiguration().set(ToEntityPrefsMapper.RATING_SHIFT, String.valueOf(0.0f));
		toUserVectors.waitForCompletion(true);

		
		int numberOfUsers = (int) toUserVectors.getCounters().findCounter(ToUserVectorsReducer.Counters.USERS).getValue();
		HadoopUtil.writeInt(numberOfUsers, countUsersPath, getConf());

		
		Job toItemVectors = prepareJob(userVectorPath, itemUserMatrixPath, SequenceFileInputFormat.class, ToItemVectorsMapper.class, IntWritable.class,
				VectorWritable.class, ToItemVectorsReducer.class, IntWritable.class, VectorWritable.class, SequenceFileOutputFormat.class);
		toItemVectors.setCombinerClass(ToItemVectorsReducer.class);

		

		int samplingSize = maxCooccurrencesPerItem;
		toItemVectors.getConfiguration().setInt(ToItemVectorsMapper.SAMPLE_SIZE, samplingSize);
		toItemVectors.waitForCompletion(true);

		
		if (numberOfUsers == -1) {
			numberOfUsers = (int) HadoopUtil.countRecords(userVectorPath, PathType.LIST, null, getConf());
		}

		
		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			try {
				ToolRunner.run(getConf(), new RowSimilarityJob(), new String[] { "-Dmapred.input.dir=" + itemUserMatrixPath,
						"-Dmapred.output.dir=" + similarityMatrixPath, "--numberOfColumns", String.valueOf(numberOfUsers), "--similarityClassname", "N/A",
						"--maxSimilaritiesPerRow", String.valueOf(maxSimilaritiesPerItem + 1), "--tempDir", tempDirPath.toString(), "--thredhold", "0.0" });
			} catch (Exception e) {
				throw new IllegalStateException("item-item-similarity computation failed", e);
			}
		}

		
		
		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			Job prePartialMultiply1 = prepareJob(similarityMatrixPath, prePartialMultiplyPath1, SequenceFileInputFormat.class,
					SimilarityMatrixRowWrapperMapper.class, VarIntWritable.class, VectorOrPrefWritable.class, Reducer.class, VarIntWritable.class,
					VectorOrPrefWritable.class, SequenceFileOutputFormat.class);
			prePartialMultiply1.waitForCompletion(true);

			
			Job prePartialMultiply2 = prepareJob(userVectorPath, prePartialMultiplyPath2, SequenceFileInputFormat.class, UserVectorSplitterMapper.class,
					VarIntWritable.class, VectorOrPrefWritable.class, Reducer.class, VarIntWritable.class, VectorOrPrefWritable.class,
					SequenceFileOutputFormat.class);

			prePartialMultiply2.getConfiguration().setInt("maxPrefsPerUserConsidered", maxPrefsPerUser);
			prePartialMultiply2.waitForCompletion(true);
			
			Job partialMultiply = prepareJob(new Path(prePartialMultiplyPath1 + "," + prePartialMultiplyPath2), partialMultiplyPath,
					SequenceFileInputFormat.class, Mapper.class, VarIntWritable.class, VectorOrPrefWritable.class, ToVectorAndPrefReducer.class,
					VarIntWritable.class, VectorAndPrefsWritable.class, SequenceFileOutputFormat.class);
			FileSystem fs = FileSystem.get(tempDirPath.toUri(), partialMultiply.getConfiguration());
			FileInputFormat.setInputPaths(partialMultiply, prePartialMultiplyPath1.makeQualified(fs), prePartialMultiplyPath2.makeQualified(fs));

			partialMultiply.waitForCompletion(true);
		}

		if (shouldRunNextPhase(parsedArgs, currentPhase)) {

			String aggregateAndRecommendInput = partialMultiplyPath.toString();

			
			Job aggregateAndRecommend = prepareJob(new Path(aggregateAndRecommendInput), outputPath, SequenceFileInputFormat.class,
					PartialMultiplyMapper.class, VarLongWritable.class, PrefAndSimilarityColumnWritable.class, AggregateAndRecommendReducer.class,
					VarLongWritable.class, RecommendedItemsWritable.class, SequenceFileOutputFormat.class);
			Configuration aggregateAndRecommendConf = aggregateAndRecommend.getConfiguration();

			setIOSort(aggregateAndRecommend);
			aggregateAndRecommendConf.set("itemIDIndexPath", itemIDIndexPath.toString());
			aggregateAndRecommendConf.setInt("numRecommendations", numRecommendations);
			aggregateAndRecommendConf.setBoolean(BOOLEAN_DATA, booleanData);
			aggregateAndRecommend.waitForCompletion(true);
		}

		if (shouldRunNextPhase(parsedArgs, currentPhase)) {
			try {
				ToolRunner.run(getConf(), new UserRecDataLoaderJob(), args);
				ToolRunner.run(getConf(), new ItemRecDataLoaderJob(), args);
			} catch (Exception e) {
				throw new IllegalStateException("Rec Data Loader failed", e);
			}
		}

		return 0;
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		ToolRunner.run(conf, new HybridRecommenderJob(), args);
	}
}
