package com.mock.dalian.tool.rec.hf.common;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mock.dalian.tool.rec.hf.util.HybridConfigurationManager;
import com.mock.dalian.tool.rec.hf.util.PerformanceTuning;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.mahout.common.HadoopUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mock.dalian.tool.rec.hf.HybridBase;


public abstract class AbstractJob extends Configured implements Tool, HybridBase {
    private static final Logger log = LoggerFactory.getLogger(AbstractJob.class);

    protected AbstractJob() {
    }

    public static void setIOSort(JobContext job) {
        Configuration conf = job.getConfiguration();
        conf.setInt("io.sort.factor", 100);
        String javaOpts = conf.get("mapred.map.child.java.opts"); 
        if (javaOpts == null) {
          javaOpts = conf.get("mapred.child.java.opts"); 
        }
        int assumedHeapSize = 512;
        if (javaOpts != null) {
          Matcher m = Pattern.compile("-Xmx([0-9]+)([mMgG])").matcher(javaOpts);
          if (m.find()) {
            assumedHeapSize = Integer.parseInt(m.group(1));
            String megabyteOrGigabyte = m.group(2);
            if ("g".equalsIgnoreCase(megabyteOrGigabyte)) {
              assumedHeapSize *= 1024;
            }
          }
        }
        
        conf.setInt("io.sort.mb", Math.min(assumedHeapSize / 2, 1024));
        conf.setInt("mapred.task.timeout", 60 * 60 * 1000);
      }
    
    protected static boolean shouldRunNextPhase(Map<String, String> args, AtomicInteger currentPhase) {
        int phase = currentPhase.getAndIncrement();
        String startPhase = args.get("startPhase");
        String endPhase = args.get("endPhase");
        boolean phaseSkipped = (startPhase != null && phase < Integer.parseInt(startPhase))
                || (endPhase != null && phase > Integer.parseInt(endPhase));
        if (phaseSkipped) {
            log.info("Skipping phase {}", phase);
        }
        return !phaseSkipped;
    }

    @SuppressWarnings("rawtypes")
    protected Job prepareJob(Path inputPath, Path outputPath, Class<? extends InputFormat> inputFormat,
            Class<? extends Mapper> mapper, Class<? extends Writable> mapperKey, Class<? extends Writable> mapperValue,
            Class<? extends Reducer> reducer, Class<? extends Writable> reducerKey,
            Class<? extends Writable> reducerValue, Class<? extends OutputFormat> outputFormat) throws IOException {
        HadoopUtil.delete(new Configuration(getConf()), outputPath);
        Job job = new Job(new Configuration(getConf()));

        PerformanceTuning.setIOSort(job);

        Configuration jobConf = job.getConfiguration();
        if (reducer.equals(Reducer.class)) {
            if (mapper.equals(Mapper.class)) {
                throw new IllegalStateException("Can't figure out the user class jar file from mapper/reducer");
            }
            job.setJarByClass(mapper);
        } else {
            job.setJarByClass(reducer);
        }

        job.setInputFormatClass(inputFormat);
        jobConf.set("mapred.input.dir", inputPath.toString());

        job.setMapperClass(mapper);
        job.setMapOutputKeyClass(mapperKey);
        job.setMapOutputValueClass(mapperValue);

        job.setReducerClass(reducer);
        job.setOutputKeyClass(reducerKey);
        job.setOutputValueClass(reducerValue);
        job.setNumReduceTasks(6);
        job.setJobName(getCustomJobName(job, mapper, reducer));

        job.setOutputFormatClass(outputFormat);
        jobConf.set("mapred.output.dir", outputPath.toString());

        return job;
    }

    @SuppressWarnings("rawtypes")
    protected Job prepareJob(Path inputPath, Path outputPath, Class<? extends Mapper> mapper,
            Class<? extends Writable> mapperKey, Class<? extends Writable> mapperValue,
            Class<? extends Reducer> reducer, Class<? extends Writable> reducerKey,
            Class<? extends Writable> reducerValue) throws IOException {
        return prepareJob(inputPath, outputPath, SequenceFileInputFormat.class, mapper, mapperKey, mapperValue,
                reducer, reducerKey, reducerValue, SequenceFileOutputFormat.class);
    }

    @SuppressWarnings("rawtypes")
    private String getCustomJobName(JobContext job, Class<? extends Mapper> mapper, Class<? extends Reducer> reducer) {
        StringBuilder name = new StringBuilder(100);
        String customJobName = job.getJobName();
        if (customJobName == null || customJobName.trim().length() == 0) {
            name.append(getClass().getSimpleName());
        } else {
            name.append(customJobName);
        }
        name.append('-').append(mapper.getSimpleName());
        name.append('-').append(reducer.getSimpleName());
        return name.toString();
    }

    protected static int readConfigAsInt(String key) {
        return Integer.valueOf(HybridConfigurationManager.getStringProperties(key, "0"));
    }

    protected static String readConfigAsString(String key) {
        return HybridConfigurationManager.getStringProperties(key, "");
    }

    protected static float readConfigAsFloat(String key) {
        return Float.valueOf(HybridConfigurationManager.getStringProperties(key, "0"));
    }

    protected String getProperty(String key, String defaultVal) {
        return HybridConfigurationManager.getStringProperties(key, defaultVal);
    }
}
