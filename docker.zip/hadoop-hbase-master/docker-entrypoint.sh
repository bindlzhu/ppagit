#!/bin/bash

echo "Start ssh and serf..."
/root/start-ssh-serf.sh

wait
echo "Configure members..."
/root/configure-members.sh
