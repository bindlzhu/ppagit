export HADOOP_HOME=/hadoop
