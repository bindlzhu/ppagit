export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
