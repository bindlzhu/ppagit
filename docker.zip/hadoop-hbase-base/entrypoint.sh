#
#  Author: Jorbin Zhu
#  Date: 2016-01-16
#
#  https://github.com/jorbinzh/docker
#
#  https://www.linkedin.com/in/jobinz
#

set -euo pipefail
[ -n "${DEBUG:-}" ] && set -x

srcdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-8-openjdk-amd64}"

echo "================================================================================"
echo "                              HBase Docker Container"
echo "================================================================================"
echo
# shell breaks and doesn't run zookeeper without this
mkdir -pv /hbase/logs

# tries to run zookeepers.sh distributed via SSH, run zookeeper manually instead now
sed -i 's/# export HBASE_MANAGES_ZK=true/export HBASE_MANAGES_ZK=true/' /hbase/conf/hbase-env.sh


sed -i "s/localhost/$hostname/" /hbase/conf/hbase-site.xml
